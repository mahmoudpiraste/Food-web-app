import React from "react";


export default function BannerOne () {


    return(
        <div className="banner-h-one-main">
            <div className="banner-h-one"><img className="img-banner-one" src="/1661690468.jpg" /></div>
           
         <div className="br-banners-one"></div>

            <div className="banner-h-two"><img  className="img-banner-two" src="/1661692320.jpg" /></div>
        </div>
    )
        
    
}