import React from "react";

export default function Loader (){
    
    
    
    return(
        <div className="main-loader-sec">
           <div className="loader-sec">
              <img style={{width:100}} src="/bresoonLogo.gif/" />
           </div>
        </div>
    )
}